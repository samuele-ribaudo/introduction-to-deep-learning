"""Definition of all datasets"""

from .dummy import Dummy
